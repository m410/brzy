object HelloWorld extends Application {
    println("Hello, world! " + args.toList)

}
HelloWorld.main(args)